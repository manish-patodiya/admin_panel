<?php
define("PERPAGE", 10);